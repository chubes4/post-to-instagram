<?php return array('dependencies' => array('react-jsx-runtime', 'wp-components', 'wp-editor', 'wp-element', 'wp-i18n', 'wp-notices', 'wp-plugins'), 'version' => '405e30e817156a593ff7');
